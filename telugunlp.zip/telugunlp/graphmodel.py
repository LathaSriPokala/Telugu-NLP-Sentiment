import pandas as pd
import pickle
import numpy as np
import matplotlib.pyplot as plt
from sklearn.calibration import calibration_curve
from sklearn.preprocessing import LabelEncoder

# Load dataset
df = pd.read_csv("telugu_sentiment_dataset_3000.csv")
X = df["sentence"]
y = df["sentiment"]

# Load model
with open("telugu_sentiment_model.pkl", "rb") as f:
    model = pickle.load(f)

# Load vectorizer
with open("telugu_vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# Convert labels to numbers for calibration
encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y)

# Convert text to TF-IDF vectors
X_vec = vectorizer.transform(X)

# Get prediction probabilities
probs = model.predict_proba(X_vec)
pred_confidence = np.max(probs, axis=1)  # Highest probability per sentence

# Get predicted classes
pred_classes = np.argmax(probs, axis=1)

# ---------- PLOT 1: Confidence Histogram ----------
plt.figure(figsize=(7, 5))
plt.hist(pred_confidence, bins=20)
plt.title("Confidence Score Distribution")
plt.xlabel("Confidence Score")
plt.ylabel("Frequency")
plt.show()

# ---------- PLOT 2: Reliability Diagram (Calibration Curve) ----------
plt.figure(figsize=(7, 5))

# Using only the confidence of predicted classes
prob_true, prob_pred = calibration_curve(
    (y_encoded == pred_classes).astype(int), pred_confidence, n_bins=10
)

plt.plot(prob_pred, prob_true, marker="o", label="Model Calibration")
plt.plot([0, 1], [0, 1], linestyle="--", label="Perfect Calibration")

plt.xlabel("Predicted Confidence")
plt.ylabel("True Accuracy")
plt.title("Reliability Diagram (Calibration Curve)")
plt.legend()
plt.show()
