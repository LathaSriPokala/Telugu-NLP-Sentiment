import pickle

# Load trained model
with open("telugu_sentiment_model.pkl", "rb") as f:
    model = pickle.load(f)

# Load vectorizer
with open("telugu_vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

print("Telugu Sentiment Analysis Prototype Ready!")
print("-------------------------------------------")

while True:
    text = input("\nEnter a Telugu sentence (or type 'exit' to quit): ")

    if text.lower() == "exit":
        print("Exiting...")
        break

    # Convert input sentence to vector
    vector = vectorizer.transform([text])

    # Predict
    prediction = model.predict(vector)[0]

    print(f"Predicted Sentiment: **{prediction}**")
